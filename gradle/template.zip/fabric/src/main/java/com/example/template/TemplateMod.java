package com.example.template;

import net.fabricmc.api.ModInitializer;

public class TemplateMod implements ModInitializer {

    @Override
    public void onInitialize() {
        Constants.LOG.info("Hello Fabric world from {}!", Constants.MOD_NAME);
        CommonClass.init();
    }
}
